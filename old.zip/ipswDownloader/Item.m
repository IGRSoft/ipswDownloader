//
//  Item.m
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 2/11/12.
//  Copyright 2012 IGR Soft. All rights reserved.
//

#import "Item.h"
#import "ASIHTTPRequest.h"

@implementation Item

@synthesize displayName = _displayName;
@synthesize details = _details;
@synthesize icon = _icon;
@synthesize tempDownloadPath = _tempDownloadPath;
@synthesize downloadPath = _downloadPath;
@synthesize request = _request;
@synthesize state = _state;
@synthesize timer = _timer;

- (void)dealloc {
    [_displayName release], _displayName = nil;
	[_details release], _details = nil;
	[_icon release], _icon = nil;
	[_tempDownloadPath release], _tempDownloadPath = nil;
	[_downloadPath release], _downloadPath = nil;
	[_request release], _request = nil;
	_state = 0;
	_timer = 0;
    [super dealloc];
}

- (NSString *)displayName {
	return _displayName;
}

- (NSString *)details {

	return _details;
}

- (NSImage *)icon {

	return _icon;
}

- (NSString *)tempDownloadPath {
	
	return _tempDownloadPath;
}

- (NSString *)downloadPath {
	
	return _downloadPath;
}

- (ASIHTTPRequest *)request {
	
	return _request;
}

- (int) state {
	
	return _state;
}

- (NSTimeInterval) itemTimer {
	
	return _timer;
}

@end
