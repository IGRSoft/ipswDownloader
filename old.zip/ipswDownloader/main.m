//
//  main.m
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 31.01.11.
//  Copyright 2011 iBrain. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    int retVal = NSApplicationMain(argc,  (const char **) argv);
    [pool release];
    return retVal;
}
