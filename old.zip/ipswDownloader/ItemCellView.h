//
//  ItemCellView.h
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 12/29/11.
//  Copyright 2011 IGR Software. All rights reserved.
//

@interface ItemCellView : NSTableCellView {
	NSTextField *_detailTextField;
	
	NSButton	*_detailPauseResumeButton;
	NSButton	*_detailShowInFinderButton;
}

@property (nonatomic, retain) IBOutlet NSTextField *detailTextField;
@property (nonatomic, retain) IBOutlet NSButton	*detailPauseResumeButton;
@property (nonatomic, retain) IBOutlet NSButton	*detailShowInFinderButton;

@end
