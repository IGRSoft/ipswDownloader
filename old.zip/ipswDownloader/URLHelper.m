//
//  URLHelper.m
//  ipswDownloader
//
//  Created by Паровишник Виталий on 28.04.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "URLHelper.h"

@implementation URLHelper

+ (NSArray* ) splitURL: (NSURL*)url
{	
	NSString* secondPart = [[NSString alloc] initWithString:[url lastPathComponent]];
	NSString* temp = [[NSString alloc] initWithString:[url relativeString]];
	int i = [temp length];
	int j = [secondPart length];
	NSString* firstPart = [[NSString alloc] initWithString:[temp substringToIndex:( i-j )]];
	
	NSArray* arr = [[NSArray alloc] initWithObjects:firstPart, secondPart, nil];
	[secondPart release];
	[firstPart release];
	[temp release];
	
	return [arr autorelease];
}

@end
