//
//  DownloadsInfo.h
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 13.03.12.
//  Copyright 2011 iBrain. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface DownloadsInfo : NSObject <NSCopying> {
	NSString*	_name;
	NSString*	_details;
	NSImage*	_icon;
}

- (id) initWithName:(NSString*)firmware details:(NSString*)speed icon:(NSImage*)image;

@property (assign) NSString*	name;
@property (assign) NSString*	details;
@property (assign) NSImage*		icon;
@end
