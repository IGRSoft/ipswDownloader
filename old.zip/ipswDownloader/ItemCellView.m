//
//  ItemCellView.h
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 12/29/11.
//  Copyright 2011 IGR Software. All rights reserved.
//

#import "ItemCellView.h"

@implementation ItemCellView

@synthesize detailTextField = _detailTextField;
@synthesize detailShowInFinderButton = _detailShowInFinderButton;
@synthesize detailPauseResumeButton = _detailPauseResumeButton;

- (void)dealloc {
	[_detailTextField release], _detailTextField = nil;
	[_detailShowInFinderButton release], _detailShowInFinderButton = nil;
	[_detailPauseResumeButton release], _detailPauseResumeButton = nil;
	
    [super dealloc];
}

- (void)setBackgroundStyle:(NSBackgroundStyle)backgroundStyle {
	NSColor *textColor = (backgroundStyle == NSBackgroundStyleDark) ? [NSColor windowBackgroundColor] : [NSColor controlShadowColor];
	self.detailTextField.textColor = textColor;
	[super setBackgroundStyle:backgroundStyle];
}

@end
