//
//  plistParser.m
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 27.12.11.
//  Copyright (c) 2011 iBrain. All rights reserved.
//

#import "plistParser.h"
#include "ZipArchive.h"

@implementation plistParserProtocol

@synthesize delegate;

- (void)processComplete
{
	[[self delegate] processSuccessful:YES];
}

- (NSMutableDictionary*) loadListWithInterval:(int)interval
{
	NSString *executableName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleExecutable"];
	NSError *error;
	NSString *result = [self findOrCreateDirectory:NSApplicationSupportDirectory
										  inDomain:NSUserDomainMask
							   appendPathComponent:executableName
											 error:&error];
	
	if (!result)
	{
		DBNSLog(@"Unable to find or create application support directory:\n%@", error);
	}
	
	bool needUpdateDB = false;
	NSFileManager* fm = [NSFileManager defaultManager];
	
	if (![fm fileExistsAtPath:[result stringByAppendingPathComponent:@"Firmware.db"]] 
		|| ![fm fileExistsAtPath:[result stringByAppendingPathComponent:@"Links.db"]]) 
	{
		needUpdateDB = true;
	}
	else if (interval == UPDATE_AT_APP_START) 
	{		
		needUpdateDB = true;
	}
	else if (interval == UPDATE_EVERY_DAY || interval == UPDATE_EVERY_WEEK)
	{		
		NSDate *now = [NSDate date];
		// Specify which units we would like to use
		unsigned units = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit;
		NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
		NSDateComponents *components = [calendar components:units fromDate:now];
		NSInteger currentDay = [components day];
		NSInteger currentMonth = [components month];
		
		NSDirectoryEnumerator *enumerator = [fm enumeratorAtPath:result];
		NSString *file = nil;
		NSDate *fileDate = nil;
		while ((file = [enumerator nextObject])) {
			
			if ([file isEqualToString:@"Firmware.db"]) {
				NSDictionary *attributes = [enumerator fileAttributes];
				
				fileDate = [attributes objectForKey:NSFileCreationDate];
			}
		}
		
		if (fileDate) {
			components = [calendar components:units fromDate:fileDate];
			NSInteger fileDay = [components day];
			NSInteger fileMonth = [components month];
			
			if (interval == UPDATE_EVERY_DAY) {
				if (currentMonth != fileMonth || (currentDay - fileDay) >= 1) {
					needUpdateDB = true;
				}
				
			} else {
				if (currentMonth != fileMonth || (currentDay - fileDay) >= 7) {
					needUpdateDB = true;
				}
			}
		}
		[calendar release];
	}
	
	if (needUpdateDB) {
		NSString *url = [NSString stringWithFormat:@"%@%@%@", FIRMWARE_URL1, FIRMWARE_URL2, FIRMWARE_URL3];
		NSData *theData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
		[theData writeToFile:[result stringByAppendingPathComponent:@"Firmware.db"] atomically:YES];
	}
	
	ZipArchive *za = [[ZipArchive alloc] init];
	NSString *pas = [NSString stringWithFormat:@"%@%@%@%@", ARCH_PASS1, ARCH_PASS2, ARCH_PASS3, ARCH_PASS4];
	if ([za UnzipOpenFile: [result stringByAppendingPathComponent:@"Firmware.db"] Password:pas]) {
		BOOL ret = [za UnzipFileTo: result overWrite: YES];
		
		if (NO == ret){} [za UnzipCloseFile];
	}
	[za release];
	NSString* tempFileName = [NSString stringWithString:[result stringByAppendingPathComponent:@"Firmware.plist"]];
	
	NSMutableDictionary* _plist;
	_plist = [[NSMutableDictionary alloc] initWithCapacity:2];
	
	[_plist setObject: [NSMutableDictionary dictionaryWithContentsOfFile:tempFileName]
			 forKey: @"firmware"];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
		[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
	}
	
	if (needUpdateDB) {
		NSString *url = [NSString stringWithFormat:@"%@%@%@", FIRMWARE_URL1, FIRMWARE_URL2, FIRMWARE_URL4];
		NSData *theData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
		[theData writeToFile:[result stringByAppendingPathComponent:@"Links.db"] atomically:YES];
	}
	
	za = [[ZipArchive alloc] init];
	pas = [NSString stringWithFormat:@"%@%@%@%@", ARCH_PASS1, ARCH_PASS2, ARCH_PASS3, ARCH_PASS4];
	if ([za UnzipOpenFile: [result stringByAppendingPathComponent:@"Links.db"] Password:pas]) {
		BOOL ret = [za UnzipFileTo: result overWrite: YES];
		
		if (NO == ret){} [za UnzipCloseFile];
	}
	[za release];
	
	tempFileName = [NSString stringWithString:[result stringByAppendingPathComponent:@"Links.plist"]];
	
	[_plist setObject: [NSMutableDictionary dictionaryWithContentsOfFile:tempFileName]
			   forKey: @"links"];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
		[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
	}
	
	return [_plist autorelease];
}

#pragma mark ==================== one firmware ==================

- (NSString*) getBaseband:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"baseband"];
}

- (NSString*) getJBIndicatir:(NSMutableDictionary*)fw
{
	bool value = false;
	NSString* image;
	
	value = [[fw objectForKey:@"jailbreak"] boolValue];
	
	if (value) {
		image = [[NSBundle mainBundle] pathForResource: @"on"
												ofType: @"png"];
	} else {
		image = [[NSBundle mainBundle] pathForResource: @"off"
												ofType: @"png"];
	}
	
	NSString *_info = [fw objectForKey:@"info"];
	
	NSRange textRange;
	textRange =[[_info lowercaseString] rangeOfString:[@"Tethered jailbreak" lowercaseString]];
	
	if(textRange.location != NSNotFound)
	{
		image = [[NSBundle mainBundle] pathForResource: @"tether"
												ofType: @"png"];
	}
	
	return image;
}

- (NSString*) getUnlockIndicatir:(NSMutableDictionary*)fw
{
	bool value = false;
	NSString* image;
	
	value = [[fw objectForKey:@"unlock"] boolValue];
	
	if (value) {
		image = [[NSBundle mainBundle] pathForResource: @"on"
												ofType: @"png"];
	} else if ([[self getBaseband:fw] isEqualToString:@"none"]) {
		image = [[NSBundle mainBundle] pathForResource: @"none"
												ofType: @"png"];
	} else {
		image = [[NSBundle mainBundle] pathForResource: @"off"
												ofType: @"png"];
	}
	
	return image;
}

- (NSString*) getSize:(NSMutableDictionary*)fw
{
	float size = 0;
	size = [[fw objectForKey:@"size"] intValue];
	size = size / BYTE_IN_MB;
	
	return [NSString stringWithFormat:@"%.2f Mb", size];
}

- (NSString*) getURL:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"url"];
}

- (NSString*) getInfo:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"info"];
}

- (NSString*) getDocks:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"docs"];
}

- (NSString*) getJBTools:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"jbtools"];
}

- (NSString*) getUnlockTools:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"utools"];
}

- (NSString*) getSHA1:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"sha1"];
}

- (NSString*) getBuild:(NSMutableDictionary*)fw
{
	return [fw objectForKey:@"build"];
}

- (NSString *)findOrCreateDirectory:(NSSearchPathDirectory)searchPathDirectory
						   inDomain:(NSSearchPathDomainMask)domainMask
				appendPathComponent:(NSString *)appendComponent
							  error:(NSError **)errorOut
{
	//
	// Search for the path
	//
	NSArray* paths = NSSearchPathForDirectoriesInDomains(searchPathDirectory, domainMask, YES);
	if ([paths count] == 0)
	{
		if (errorOut)
		{
			NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedStringFromTable(@"No path found for directory in domain.", @"Errors", nil),
									  NSLocalizedDescriptionKey,
									  [NSNumber numberWithInteger:searchPathDirectory],
									  @"NSSearchPathDirectory",
									  [NSNumber numberWithInteger:domainMask],
									  @"NSSearchPathDomainMask",
									  nil];
			*errorOut = [NSError errorWithDomain:@"DirectoryLocationDomain"
											code:DirectoryLocationErrorNoPathFound
										userInfo:userInfo];
		}
		return nil;
	}
	
	//
	// Normally only need the first path returned
	//
	NSString *resolvedPath = [paths objectAtIndex:0];
	
	//
	// Append the extra path component
	//
	if (appendComponent)
	{
		resolvedPath = [resolvedPath stringByAppendingPathComponent:appendComponent];
	}
	
	//
	// Check if the path exists
	//
	BOOL exists;
	BOOL isDirectory;
	exists = [[NSFileManager defaultManager] fileExistsAtPath:resolvedPath 
												  isDirectory:&isDirectory];
	
	if (!exists || !isDirectory)
	{
		if (exists)
		{
			if (errorOut)
			{
				NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedStringFromTable(	@"File exists at requested directory location.", @"Errors", nil),
										  NSLocalizedDescriptionKey,
										  [NSNumber numberWithInteger:searchPathDirectory],
										  @"NSSearchPathDirectory",
										  [NSNumber numberWithInteger:domainMask],
										  @"NSSearchPathDomainMask",
										  nil];
				*errorOut = [NSError errorWithDomain:@"DirectoryLocationDomain"
												code:DirectoryLocationErrorFileExistsAtLocation
											userInfo:userInfo];
			}
			return nil;
		}
		
		//
		// Create the path if it doesn't exist
		//
		NSError *error = nil;
		BOOL success = [[NSFileManager defaultManager] createDirectoryAtPath:resolvedPath
												 withIntermediateDirectories:YES
																  attributes:nil
																	   error:&error];
		if (!success) 
		{
			if (errorOut)
			{
				*errorOut = error;
			}
			return nil;
		}
	}
	
	if (errorOut)
	{
		*errorOut = nil;
	}
	return resolvedPath;
}


@end