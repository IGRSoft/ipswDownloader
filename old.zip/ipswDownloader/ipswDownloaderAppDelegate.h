//
//  ipswDownloaderAppDelegate.h
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 31.01.11.
//  Copyright 2011 iBrain. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>
#import <AudioToolbox/AudioToolbox.h>
#import <Growl/Growl.h>

#import "plistParser.h"

@class IKImageView;
@class ASIHTTPRequest;
@class ASINetworkQueue;
@class PreferenceController;

@interface ipswDownloaderAppDelegate : NSObject <NSApplicationDelegate, GrowlApplicationBridgeDelegate, plistParserDelegate> {
	
	NSWindow*						window;
	IBOutlet NSView*				miainView, *progressView;
	PreferenceController*			m_Preference;
	plistParserProtocol*			m_plistParserProtocol;
	
	NSURL*							m_DownloadURL;
	NSURL*							m_DocsURL;
	NSMutableDictionary*			m_PlistDict;
	NSMutableDictionary*			m_LinksDict;
	NSMutableDictionary*			m_FirmwareList;
	
	IBOutlet NSProgressIndicator*	m_Progress;
	IBOutlet NSProgressIndicator*	m_Animation;
	IBOutlet NSComboBox*			m_Device;
	IBOutlet NSComboBox*			m_Firmware;
	IBOutlet NSButton*				m_DownloadButton;
	IBOutlet NSButton*				m_CancelButton;
	IBOutlet NSButton*				m_PauseResumeButton;
	IBOutlet NSButton*				m_NeedOpenFolder;
	IBOutlet NSButton*				m_InfoButton;
	
	NSTimeInterval					startDownload;
	ASINetworkQueue					*networkQueue;
	ASIHTTPRequest					*bigFetchRequest;
	
	//Info
	IBOutlet NSTextField*			m_FirmwareBaseband;
	IBOutlet IKImageView*			m_FirmwareJailbreak;
	IBOutlet IKImageView*			m_FirmwareUnlock;
	IBOutlet NSTextField*			m_FirmwareSize;
	IBOutlet NSTextField*			m_FirmwareInfo;
	IBOutlet NSTextField*			m_FirmwareJBTools;
	IBOutlet NSTextField*			m_FirmwareUTools;
	IBOutlet NSTextField*			m_DownloadFileName;
	IBOutlet NSTextField*			m_DownloadDestinationPath;
	IBOutlet NSTextField*			m_FirmwareSHA1;
	IBOutlet NSTextField*			m_FirmwareBuild;
	
	IBOutlet NSTextField*			m_DownloadSize;
	IBOutlet NSTextField*			m_DownloadTime;
	IBOutlet NSBox*					m_DetailsBox;
	IBOutlet NSMenuItem*			m_simpleModeMenu;
	
	NSString*						m_DownloadPath;
	
	NSInteger						alertReturnStatus;
	NSTimer							*DownloadUpdateTimer;
	bool							isPaused;
	
	//prefs
	int								m_dbUpdateInterval;
	bool							m_bUseSound;
	bool							m_bSimpleMode;
	bool							m_bShowGrowl;
	bool							m_bInternet;
	bool							m_bNeedCheckCRC;
	bool							m_bShowNotification;
	
	//menus
	IBOutlet NSMenu*				m_ToolsMenu;
	IBOutlet NSMenu*				m_SupportMenu;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) NSMutableDictionary *m_FirmwareList;
@property (retain, nonatomic) ASIHTTPRequest *bigFetchRequest;
@property (retain, nonatomic) NSString*	m_DownloadPath;

- (IBAction)downloadIPSW:(id) sender;
- (IBAction)selectDevice:(id) sender;
- (IBAction)selectFirmware:(id) sender;
- (IBAction)goToURL:(id) sender;
- (IBAction)cancelDownload:(id) sender;
- (IBAction)pauseURLFetchWithProgress:(id) sender;
- (IBAction)resumeURLFetchWithProgress:(id) sender;
- (IBAction)appleInfo:(id) sender;
- (IBAction)openPreference:(id) sender;
- (IBAction)simpleMode:(id) sender;
- (IBAction)reloadDB:(id) sender;
- (void) addItemsToDevice;
- (void) addItemsToFirmware: (NSString*)device;
- (void) updateInfo: (NSString*)firmware;

- (void)openImageURLfor:(IKImageView*)_imageView withUrl:(NSURL*)url;
- (NSArray* ) splitURL: (NSURL*)url;

- (void) setView: (NSString *) viewName;
- (id) init;
- (void) dealloc;

- (BOOL) internetEnabled;
- (void) startAlert:(NSAlert*) alert selector:(SEL)alertSelector;

- (void) playSystemSound:(NSString*) name;

- (void) setHiperLinkForTextField:(NSTextField*) textField;

- (void) setControlsEnabled:(BOOL) yesno;

@end
