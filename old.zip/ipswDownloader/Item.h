//
//  Item.h
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 2/11/12.
//  Copyright 2012 IGR Soft. All rights reserved.
//

@class ASIHTTPRequest;

enum DownloadStatus {
	DOWNLOAD_IN_PROGRESS = 0,
	DOWNLOAD_PAUSED,
	DOWNLOAD_COMPLEATED,
	DOWNLOAD_FAILED,
	
	DOWNLOAD_COUNT
	
};

@interface Item : NSObject {
	NSString		*_displayName;
	NSString		*_details;
	NSImage			*_icon;
	NSString		*_tempDownloadPath;
	NSString		*_downloadPath;
	ASIHTTPRequest	*_request;
	int				 _state;
	NSTimeInterval	 _timer;
}

@property (nonatomic, copy) NSString			*displayName;
@property (nonatomic, copy) NSString			*details;
@property (nonatomic, copy) NSImage				*icon;
@property (nonatomic, copy) NSString			*tempDownloadPath;
@property (nonatomic, copy) NSString			*downloadPath;
@property (nonatomic, assign) ASIHTTPRequest	*request;
@property (nonatomic, assign) int				state;
@property (nonatomic, assign) NSTimeInterval	timer;

@end
