//
//  DownloadsManager.m
//  ipswDownloader
//
//  Created by Паровишник Виталий on 01.03.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DownloadsManager.h"
#import "PreferenceController.h"

#import "ASIHTTPRequest.h"

#import "sha1.h"
#import <AudioToolbox/AudioToolbox.h>
#import "URLHelper.h"

extern bool needWaitProcess;

@interface DownloadsManager ()
- (void) URLFetchWithProgressComplete:(ASIHTTPRequest *)request;
- (void) URLFetchWithProgressFailed:(ASIHTTPRequest *)request;
- (void) playSystemSound:(NSString*) name;
@end

@implementation DownloadsManager

static id sharedInstance = nil;

+ (id) sharedInstance { 
    return [self sharedInstance:&sharedInstance];
}

+ (id) sharedInstance:(id*)inst {
    @synchronized(self)
    {
        if (*inst == nil)
            *inst = [[self alloc] init];
    }
    return *inst;
}

+ (id) allocWithZone:(NSZone *)zone forInstance:(id*)inst {
    @synchronized(self) {
        if (*inst == nil) {
            *inst = [super allocWithZone:zone];
            return *inst;  // assignment and return on first allocation
        }
    }
    return nil; // on subsequent allocation attempts return nil
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

- (id)retain {
    return self;
}

- (NSUInteger)retainCount {
    return UINT_MAX;  // denotes an object that cannot be released
}

- (oneway void)release {
    //do nothing
}

- (id)autorelease {
    return self;
}

- (void)setup {
	[GrowlApplicationBridge setGrowlDelegate: self];
}

- (BOOL) addDownloadFile:(NSURL*)downloadURL withSHA1:(NSString*)downloadSHA1
{
	NSString* fileName = [NSString stringWithString:[[URLHelper splitURL:downloadURL] objectAtIndex:1]];
	
	NSString *downloadsDirectory = [NSSearchPathForDirectoriesInDomains(NSDownloadsDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	
	NSString* tempFileName = [NSMutableString string];
	bool mayStart = false;
	tempFileName = [NSString stringWithString:[downloadsDirectory stringByAppendingFormat:@"/%@.download", fileName]];
	if (![[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
		mayStart = true;
	}
	int shift = 1;
	
	while (!mayStart) {
		NSRange range = [fileName rangeOfString:@".ipsw"];
		NSString *tmp = [NSString stringWithFormat:@"%@_%d%@", [fileName substringToIndex:(range.location)], shift++, [fileName substringFromIndex:range.location]];
		tempFileName = [NSString stringWithString:[downloadsDirectory stringByAppendingFormat:@"/%@.download", tmp]];
		if (![[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
			fileName = tmp;
			mayStart = true;
		}
	}

	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:downloadURL];
	[request setDownloadDestinationPath:[downloadsDirectory stringByAppendingFormat:@"/%@", fileName]];
	[request setTemporaryFileDownloadPath:tempFileName];
	
	[request setPassword:downloadSHA1];
	
	[self startDownloadWithRequest:request AtIndex:-1];
	
	return YES;
}

- (void)startDownloadWithRequest:(ASIHTTPRequest*)request AtIndex:(int)index
{
	[request setAllowResumeForFileDownloads:YES];
	[request setDelegate:self];
	[request setDidFinishSelector:@selector(URLFetchWithProgressComplete:)];
	[request setDidFailSelector:@selector(URLFetchWithProgressFailed:)];
	
	[request startAsynchronous];
	
	NSString* fileName = [NSString stringWithString:[[URLHelper splitURL:[request url]] objectAtIndex:1]];
	
	NSImage *img = [[NSImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource: @"document"
																						   ofType: @"png"]];
	NSMutableArray *ma = [[NSMutableArray alloc] init];
	NSDictionary * expDict = [NSDictionary dictionaryWithObjectsAndKeys:
							  img, @"Picture",
							  fileName, @"Name",
							  NSLocalizedString(@"Expect to start download", @"Expect to start download"), @"Details", 
							  request, @"Request",
							  [NSNumber numberWithInt:index], @"index",
							  [request downloadDestinationPath], @"downloadDestinationPath",
							  [request temporaryFileDownloadPath] , @"temporaryFileDownloadPath",
							  nil];
	
	[ma addObject:expDict];
	
	[[NSNotificationCenter defaultCenter] postNotificationName:ADD_DOWNLOAD_OBJECT_NOTIFICATION
														object:ma];
	
	[img release];
	[ma release];
}

- (void)URLFetchWithProgressComplete:(ASIHTTPRequest *)request
{
	needWaitProcess = true;
	[[NSNotificationCenter defaultCenter] postNotificationName:REMOVE_DOWNLOAD_OBJECT_NOTIFICATION
														object:[request downloadDestinationPath]];
	
	bool m_bNeedCheckCRC = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsCheckSHA1Key];
	if (m_bNeedCheckCRC)
	{
		CFStringRef sha1hash = FileSHA1HashCreateWithPath((CFStringRef)[request downloadDestinationPath], FileHashDefaultChunkSizeForReadingData);
		DBNSLog(@"SHA1 hash of file at path \"%@\": %@", [request downloadDestinationPath], (NSString *)sha1hash);
		
		NSString *sha1 =[request password];
		
		if (![sha1 isEqualToString:(NSString *)sha1hash]) {
			
			bool m_bShowNotification = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsUseNotificationKey];
			
			if (m_bShowNotification) {
				//Growl
				[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
											description: NSLocalizedString(GROWL_CHECKSUM_FAIL, @"Growl SHA1 Checksum Fail") notificationName: GROWL_CHECKSUM_FAIL
											   iconData: nil priority: 0 isSticky: NO clickContext: nil];
			}
			else {
				DBNSLog(@"%@", NSLocalizedString(GROWL_CHECKSUM_FAIL, @"Growl SHA1 Checksum Fail"));
			}
			
			
			if ([[NSFileManager defaultManager] fileExistsAtPath:[request downloadDestinationPath]]) {
				[[NSFileManager defaultManager] removeItemAtPath:[request downloadDestinationPath] error:nil];
			}
			[self playSystemSound:@"Basso"];
		}
		else {
			bool m_bShowNotification = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsUseNotificationKey];
			
			if (m_bShowNotification) {
			//Growl
				NSMutableDictionary * clickContext = [NSMutableDictionary dictionaryWithObject: GROWL_DOWNLOAD_COMPLETE forKey: @"Type"];
				
				[clickContext setObject: [request downloadDestinationPath] forKey: @"Location"];
				
				[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
											description: NSLocalizedString(GROWL_DOWNLOAD_COMPLETE, @"Growl Download Complete") notificationName: GROWL_DOWNLOAD_COMPLETE
											   iconData: nil priority: 0 isSticky: NO clickContext: clickContext];
			}
			[self playSystemSound:@"Tink"];
		}
		CFRelease(sha1hash);
	}
	else {
		bool m_bShowNotification = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsUseNotificationKey];
		
		if (m_bShowNotification) {
			//Growl
			NSMutableDictionary * clickContext = [NSMutableDictionary dictionaryWithObject: GROWL_DOWNLOAD_COMPLETE forKey: @"Type"];
			
			[clickContext setObject: [request downloadDestinationPath] forKey: @"Location"];
			
			[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
										description: NSLocalizedString(GROWL_DOWNLOAD_COMPLETE, @"Growl Download Complete") notificationName: GROWL_DOWNLOAD_COMPLETE
										   iconData: nil priority: 0 isSticky: NO clickContext: clickContext];
		}
		
		[self playSystemSound:@"Tink"];
	}
}

- (void)URLFetchWithProgressFailed:(ASIHTTPRequest *)request
{	
	if (![request isCancelled]) {
		needWaitProcess = true;
		[[NSNotificationCenter defaultCenter] postNotificationName:FAILED_DOWNLOAD_OBJECT_NOTIFICATION
															object:request.temporaryFileDownloadPath];
	}
	
	if ([[request error] domain] == NetworkRequestErrorDomain && [[request error] code] == ASIRequestCancelledErrorType) {
		//[fileLocation setStringValue:@"(Request paused)"];
	} else {
		
		//Growl
		// Inform the user.
		DBNSLog(@"Download failed! Error - %@ %@",
				[[request error] localizedDescription],
				[[[request error] userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
		bool m_bShowNotification = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsUseNotificationKey];
		
		if (m_bShowNotification) {
			[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
										description: NSLocalizedString(GROWL_DOWNLOAD_FAIL, @"Growl Download Fail") notificationName: GROWL_DOWNLOAD_FAIL
										   iconData: nil priority: 0 isSticky: NO clickContext: nil];
		}
		[self playSystemSound:@"Basso"];
	}
}

- (void) playSystemSound:(NSString*) name
{
	bool m_bUseSound = [[NSUserDefaults standardUserDefaults] boolForKey:defaultsUseSoundKey];
	if (!m_bUseSound) {
		return;
	}
	
	NSString* soundFile = [[NSString alloc] initWithFormat:@"/System/Library/Sounds/%@.aiff", name];
	
	NSFileManager *fm = [NSFileManager defaultManager];
	
	if ([ fm fileExistsAtPath:soundFile] == YES) {		
		NSURL* filePath = [NSURL fileURLWithPath: soundFile isDirectory: NO];
		SystemSoundID soundID;
		AudioServicesCreateSystemSoundID((CFURLRef)filePath, &soundID);
		AudioServicesPlaySystemSound(soundID);
	}
	[soundFile release];
}


#pragma mark ---- Growl ----

- (NSDictionary *) registrationDictionaryForGrowl
{
    NSArray * notifications = [NSArray arrayWithObjects: GROWL_DOWNLOAD_COMPLETE, 
							   GROWL_DOWNLOAD_FAIL, 
							   GROWL_CHECKSUM_FAIL, 
							   GROWL_DOWNLOAD_CANCELED,
							   nil];
	
    return [NSDictionary dictionaryWithObjectsAndKeys: notifications, GROWL_NOTIFICATIONS_ALL, notifications, GROWL_NOTIFICATIONS_DEFAULT, nil];
}

- (void) growlNotificationWasClicked: (id) clickContext
{
    if (!clickContext || ![clickContext isKindOfClass: [NSDictionary class]])
        return;
    
    NSString * type = [clickContext objectForKey: @"Type"], * location;
    if (([type isEqualToString: GROWL_DOWNLOAD_COMPLETE])
		&& (location = [clickContext objectForKey: @"Location"]))
    {
		[[NSWorkspace sharedWorkspace] selectFile: location inFileViewerRootedAtPath: nil];
    }
}

@end

