//
//  DownloadsInfo.m
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 13.03.12.
//  Copyright 2011 iBrain. All rights reserved.
//

#import "DownloadsInfo.h"

@implementation DownloadsInfo

@synthesize name = _name;
@synthesize details = _details;
@synthesize icon = _icon;

- (id) initWithName:(NSString*)firmware details:(NSString*)speed icon:(NSImage*)image
{
	if (self = [super init]) {
		_name = [firmware retain];
		_details = [speed retain];
		_icon = [image retain];
	}
	return self;
}

// When an instance is assigned as objectValue to a NSCell, the NSCell creates a copy.
// Therefore we have to implement the NSCopying protocol
- (id)copyWithZone:(NSZone *)zone {
    DownloadsInfo *copy = [[[self class] allocWithZone: zone] initWithName:_name details:_details icon: _icon];
    return copy;
}

- (void) dealloc {
	self.name = nil;
	self.details = nil;
	self.icon = nil;
	[super dealloc];
}

@end
