//
//  URLHelper.h
//  ipswDownloader
//
//  Created by Паровишник Виталий on 28.04.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface URLHelper : NSObject

+ (NSArray* ) splitURL: (NSURL*)url;

@end
