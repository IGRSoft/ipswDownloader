//
//  ipswDownloaderAppDelegate.m
//  ipswDownloader
//
//  Created by Vitaly Parovishnik on 31.01.11.
//  Copyright 2011 iBrain. All rights reserved.
//

#import "ipswDownloaderAppDelegate.h"
#import "PreferenceController.h"
#import "Reachability.h"

// Cryptography
#import <CommonCrypto/CommonDigest.h>

#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"

#import "ZipArchive.h"

// In bytes
#define FileHashDefaultChunkSizeForReadingData 4096

@interface ipswDownloaderAppDelegate ()
- (void)URLFetchWithProgressComplete:(ASIHTTPRequest *)request;
- (void)URLFetchWithProgressFailed:(ASIHTTPRequest *)request;
@end

@implementation ipswDownloaderAppDelegate

@synthesize window;
@synthesize m_FirmwareList;
@synthesize bigFetchRequest;
@synthesize m_DownloadPath;

- (void) processSuccessful:(BOOL)success
{
	NSLog(@"Process completed");
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	
	m_bInternet = false;
	[[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(reachabilityChanged:) 
                                                 name:kReachabilityChangedNotification 
                                               object:nil];
	
    
    Reachability * reach = [Reachability reachabilityWithHostname:@"igrsoft.com"];
    
    reach.reachableBlock = ^(Reachability * reachability)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            m_bInternet = true;
        });
    };
    
    reach.unreachableBlock = ^(Reachability * reachability)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            m_bInternet = false;
        });
    };
    
    [reach startNotifier];
	
	NSUserDefaults* appPrefs = [NSUserDefaults standardUserDefaults];
	
	m_dbUpdateInterval = [appPrefs integerForKey:defaultsDBUpdateKey];
	m_bUseSound = [appPrefs boolForKey:defaultsUseSoundKey];
	m_bNeedCheckCRC = [appPrefs boolForKey:defaultsCheckSHA1Key];
	m_bShowNotification = [appPrefs boolForKey:defaultsUseNotificationKey];
	m_bSimpleMode = [appPrefs boolForKey:defaultsSimpleModeKey];
	
	[self simpleMode:nil];
	[self setControlsEnabled: NO];
	
	NSString* path = [[NSBundle mainBundle] pathForResource: @"none"
													 ofType: @"png"];
    NSURL* url = [NSURL fileURLWithPath: path];
    
	[self openImageURLfor: m_FirmwareUnlock withUrl: url];
	[self openImageURLfor: m_FirmwareJailbreak withUrl: url];
}

- (id) init {
	if (!(self = [super init])) 
	{
		return nil;
	}

	m_plistParserProtocol = [[plistParserProtocol alloc] init];
	[m_plistParserProtocol setDelegate:self];
	
	networkQueue = [[ASINetworkQueue alloc] init];
	
	m_FirmwareList = [[NSMutableDictionary alloc] init];
	
	[GrowlApplicationBridge setGrowlDelegate: self];
	isPaused = false;
	m_bShowGrowl = false;
	
    return self;
}

- (void) dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	
	[m_plistParserProtocol release];
	
	[m_FirmwareList release];
	[m_PlistDict release];
	[m_LinksDict release];
	[m_DownloadURL release];
	[m_DocsURL release];
	
	[networkQueue release];
	
	[super dealloc];
}

#pragma mark ---- Download Manager ----

- (void)updateDownloadInfo
{
	if (isPaused)
		return;
	
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	float speed = (float)([ASIHTTPRequest averageBandwidthUsedPerSecond]) / BYTE_IN_MB;
	float size = (float)([bigFetchRequest contentLength] + [bigFetchRequest partialDownloadSize]) / BYTE_IN_MB;
	float cur_size = (float)([bigFetchRequest totalBytesRead]+[bigFetchRequest partialDownloadSize]) / BYTE_IN_MB;

	double percentComplete = (cur_size / size) * 100.0 + 0.5;
	
	NSString* text;
	if (percentComplete >= 0)
		text = [NSString stringWithFormat:@"%i %%", (int)percentComplete];
	else
		text = [NSString stringWithString:@""];
	
	NSDockTile*	dockTile = [NSApp dockTile];
	[dockTile setBadgeLabel:text];
	[dockTile display];
	
	text = [NSString stringWithFormat:NSLocalizedString(@"%.2f / %.2f Mb  (%.2f Mb/s)", @"Download size"), cur_size, size, speed];
	[m_DownloadSize setStringValue:text];
	
	int _time = (size - cur_size) / speed;
	if (_time > 60) {
		text = [NSString stringWithFormat:NSLocalizedString(@"%i min %i sec", @"Download time min/sec"), (_time/60), (_time % 60)];
	}
	if (_time <= 60) {
		text = [NSString stringWithFormat:NSLocalizedString(@"%i sec", @"Download time sec"), _time];
	}
	if (_time < 0) {
		text = [NSString stringWithString:NSLocalizedString(@"Expect to start download", @"Expect to start download")];
	}
	[m_DownloadTime setStringValue:text];
#if defined (DEMO)
	if (percentComplete > 5) {
		[[self bigFetchRequest] cancel];
		[self setBigFetchRequest:nil];
		[self setView:@"main"];
		[dockTile setBadgeLabel:@""];
		
		NSString* tempFileName = [[NSString alloc] initWithString:[m_DownloadPath stringByAppendingString:@".download"]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
			[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
		}
		[tempFileName release];
		
		NSAlert* alert = [[NSAlert alloc] init];
		int result;
		
		[alert setMessageText:@"Demo!"];
		[alert addButtonWithTitle:@"ok"];
		[alert setInformativeText:@"It's demo version for test, wait 1 day for release ;)"];
		[alert setAlertStyle:NSWarningAlertStyle];
		
		result = [alert runModal];
		
		if (NSAlertFirstButtonReturn == result)
		{
			DBNSLog(@"OKAY");
		}
		
		[alert release];

	}
#endif
	
	[pool release];
}

- (IBAction)downloadIPSW:(id)sender
{
	if (![self internetEnabled]) {
		return;
	}
	
	NSString* fileName = [[NSString alloc] initWithString:[[self splitURL:m_DownloadURL] objectAtIndex:1]];
	// Create the NSSavePanel class
	NSSavePanel* sPanel = [NSSavePanel savePanel];
	
	[sPanel setAllowedFileTypes:[NSArray arrayWithObjects: @"ipsw", nil ]];
	[sPanel setCanCreateDirectories:YES];
	[sPanel setAlphaValue:0.95];
	[sPanel setTitle:NSLocalizedString(@"Download to", @"Download to")];
	
	NSString *desktopPath = [NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	
	[sPanel setNameFieldStringValue:fileName];
	[sPanel setDirectoryURL:[NSURL URLWithString:desktopPath]];
	// Display the dialog.  If the OK button was pressed,
	// process the files.
	[sPanel beginSheetModalForWindow:window completionHandler:^(NSInteger result) 
	 {
		 if (result == NSFileHandlingPanelOKButton)
			{ 
				m_bShowGrowl = false;
				
				m_DownloadPath = [[NSString alloc] initWithString:[[sPanel URL] path]];
				
				[m_DownloadFileName setStringValue:[m_DownloadPath substringFromIndex:[[m_DownloadPath stringByDeletingLastPathComponent] length]+1]];
				[m_DownloadDestinationPath setStringValue:[[sPanel directoryURL] path]];
				
				NSString* tempFileName = [[NSString alloc] initWithString:[m_DownloadPath stringByAppendingString:@".download"]];
				if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
					[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
				}
				
				[tempFileName release];
				
				[self setView:@"process"];
				
				[self resumeURLFetchWithProgress:self];
				
				startDownload = [NSDate timeIntervalSinceReferenceDate];
				
				DownloadUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateDownloadInfo) userInfo:nil repeats:YES];
			}
	 }];

	[fileName release];
}

- (IBAction)pauseURLFetchWithProgress:(id)sender
{
	if (m_bShowNotification) {
		[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
									description: NSLocalizedString(GROWL_DOWNLOAD_PAUSED, @"Growl Download Fail") notificationName: GROWL_DOWNLOAD_PAUSED
									   iconData: nil priority: 0 isSticky: NO clickContext: nil];
	}
	
	[m_PauseResumeButton setTitle:NSLocalizedString(@"Resume" , "Resume")];
	[m_PauseResumeButton setAction:@selector(resumeURLFetchWithProgress:)];
	
	[[self bigFetchRequest] cancel];
	[self setBigFetchRequest:nil];
	
	isPaused = true;
}

- (IBAction)resumeURLFetchWithProgress:(id)sender
{
	if (m_bShowGrowl && m_bShowNotification) {
		[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
									description: NSLocalizedString(GROWL_DOWNLOAD_RESUME, @"Growl Download Fail") notificationName: GROWL_DOWNLOAD_RESUME
									   iconData: nil priority: 0 isSticky: NO clickContext: nil];
	}
	
	m_bShowGrowl = true;
	
	[m_PauseResumeButton setTitle:NSLocalizedString(@"Pause" , "Pause")];
	[m_PauseResumeButton setAction:@selector(pauseURLFetchWithProgress:)];
	
	NSString* tempFileName = [[NSString alloc] initWithString:[m_DownloadPath stringByAppendingString:@".download"]];

	// Stop any other requests
	[networkQueue reset];
	
	[self setBigFetchRequest:[ASIHTTPRequest requestWithURL:m_DownloadURL]];
	DBNSLog(@"path - %@", m_DownloadPath);
	[[self bigFetchRequest] setDownloadDestinationPath:m_DownloadPath];
	[[self bigFetchRequest] setTemporaryFileDownloadPath:tempFileName];
	[[self bigFetchRequest] setAllowResumeForFileDownloads:YES];
	[[self bigFetchRequest] setDelegate:self];
	[[self bigFetchRequest] setDidFinishSelector:@selector(URLFetchWithProgressComplete:)];
	[[self bigFetchRequest] setDidFailSelector:@selector(URLFetchWithProgressFailed:)];
	[[self bigFetchRequest] setDownloadProgressDelegate:m_Progress];
	[[self bigFetchRequest] startAsynchronous];
	[tempFileName release];
	
	isPaused = false;
}

- (void)URLFetchWithProgressComplete:(ASIHTTPRequest *)request
{
	if (m_bNeedCheckCRC)
	{
		CFStringRef sha1hash = FileSHA1HashCreateWithPath((CFStringRef)m_DownloadPath, FileHashDefaultChunkSizeForReadingData);
		DBNSLog(@"SHA1 hash of file at path \"%@\": %@", m_DownloadPath, (NSString *)sha1hash);
		
		NSString *sha1 = [[NSString alloc] initWithString:[m_FirmwareSHA1 stringValue]];
		
		if (![sha1 isEqualToString:(NSString *)sha1hash]) {
			//Growl
			if (m_bShowNotification) {
				[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
											description: NSLocalizedString(GROWL_CHECKSUM_FAIL, @"Growl SHA1 Checksum Fail") notificationName: GROWL_CHECKSUM_FAIL
											   iconData: nil priority: 0 isSticky: NO clickContext: nil];
			}
			
			[self playSystemSound:@"Basso"];
			
			if ([[NSFileManager defaultManager] fileExistsAtPath:m_DownloadPath]) {
				[[NSFileManager defaultManager] removeItemAtPath:m_DownloadPath error:nil];
			}
			
		}
		else {
			//Growl
			NSMutableDictionary * clickContext = [NSMutableDictionary dictionaryWithObject: GROWL_DOWNLOAD_COMPLETE forKey: @"Type"];
			
			[clickContext setObject: m_DownloadPath forKey: @"Location"];
			
			if (m_bShowNotification) {
				[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
											description: NSLocalizedString(GROWL_DOWNLOAD_COMPLETE, @"Growl Download Complete") notificationName: GROWL_DOWNLOAD_COMPLETE
											   iconData: nil priority: 0 isSticky: NO clickContext: clickContext];
			}
			
			if ([m_NeedOpenFolder state]) {
				[[NSWorkspace sharedWorkspace] selectFile: m_DownloadPath inFileViewerRootedAtPath: nil];
			}
			
			[self playSystemSound:@"Tink"];
		}
		[sha1 release];
		CFRelease(sha1hash);
	}
	else {
		NSMutableDictionary * clickContext = [NSMutableDictionary dictionaryWithObject: GROWL_DOWNLOAD_COMPLETE forKey: @"Type"];
		
		[clickContext setObject: m_DownloadPath forKey: @"Location"];
		
		if (m_bShowNotification) {
			[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
										description: NSLocalizedString(GROWL_DOWNLOAD_COMPLETE, @"Growl Download Complete") notificationName: GROWL_DOWNLOAD_COMPLETE
										   iconData: nil priority: 0 isSticky: NO clickContext: clickContext];
		}
		
		if ([m_NeedOpenFolder state]) {
			[[NSWorkspace sharedWorkspace] selectFile: m_DownloadPath inFileViewerRootedAtPath: nil];
		}
		
		[self playSystemSound:@"Tink"];
	}
	
	//remove Timer
	[DownloadUpdateTimer invalidate];
	DownloadUpdateTimer = nil;
	
	[m_DownloadPath release];
	[self setView:@"main"];
	NSDockTile*	dockTile = [NSApp dockTile];
	[dockTile setBadgeLabel:@""];
	
	
}

- (void)URLFetchWithProgressFailed:(ASIHTTPRequest *)request
{
	if ([[request error] domain] == NetworkRequestErrorDomain && [[request error] code] == ASIRequestCancelledErrorType) {
		//[fileLocation setStringValue:@"(Request paused)"];
	} else {
		//remove Timer
		[DownloadUpdateTimer invalidate];
		DownloadUpdateTimer = nil;
		
		//Growl
		// Inform the user.
		DBNSLog(@"Download failed! Error - %@ %@",
			  [[request error] localizedDescription],
			  [[[request error] userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
		
		if (m_bShowNotification) {
			[GrowlApplicationBridge notifyWithTitle: NSLocalizedString(@"ipswDownloader", "Growl notification title")
										description: NSLocalizedString(GROWL_DOWNLOAD_FAIL, @"Growl Download Fail") notificationName: GROWL_DOWNLOAD_FAIL
										   iconData: nil priority: 0 isSticky: NO clickContext: nil];
		}
		
		[m_DownloadPath release];
		[self setView:@"main"];
		NSDockTile*	dockTile = [NSApp dockTile];
		[dockTile setBadgeLabel:@""];
		
		[self playSystemSound:@"Basso"];
		
		NSString* tempFileName = [[NSString alloc] initWithString:[m_DownloadPath stringByAppendingString:@".download"]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
			[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
		}
		[tempFileName release];
	}
}

- (NSArray* ) splitURL: (NSURL*)url
{	
	NSString* secondPart = [[NSString alloc] initWithString:[url lastPathComponent]];
	NSString* temp = [[NSString alloc] initWithString:[url relativeString]];
	int i = [temp length];
	int j = [secondPart length];
	NSString* firstPart = [[NSString alloc] initWithString:[temp substringToIndex:( i-j )]];
	
	NSArray* arr = [[NSArray alloc] initWithObjects:firstPart, secondPart, nil];
	[secondPart release];
	[firstPart release];
	[temp release];
	
	return [arr autorelease];
	
}

-(IBAction) cancelDownload: (id) sender
{
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setAlertStyle:NSInformationalAlertStyle];
	[alert addButtonWithTitle:NSLocalizedString(@"No", @"No")];
	[alert addButtonWithTitle:NSLocalizedString(@"Yes", @"Yes")];
	[alert setMessageText:NSLocalizedString(@"Cancel Download", @"Cancel Download")];
	[alert setInformativeText:NSLocalizedString(@"Are you sure want to cancel?", @"Are you sure want to cancel?")];
	
	[self startAlert:alert selector:@selector(closeAlert:returnCode:contextInfo:)];
	[alert release];
}

#pragma mark ---- Firmware ----

- (IBAction) selectDevice:(id)sender
{
	[self addItemsToFirmware: [sender stringValue]];
}

- (IBAction)selectFirmware: (id)sender
{
	[self updateInfo:[sender stringValue]];
}

- (void) addItemsToDevice
{
	if (!m_PlistDict && [m_PlistDict count] == 0 )
	{
		NSAlert *alert = [[[NSAlert alloc] init] autorelease];
		[alert addButtonWithTitle:NSLocalizedString(@"OK", @"OK")];
		[alert setMessageText:NSLocalizedString(@"Connection error", @"Connection error")];
		[alert setInformativeText:NSLocalizedString(@"Can't download ipsw list", @"Can't download ipsw list")];
		[alert setAlertStyle:NSCriticalAlertStyle];
		
		[self startAlert:alert selector:@selector(closeAlert:returnCode:contextInfo:)];
		
		return;
	}
	
	[m_Device removeAllItems];
	
	NSArray* arrayKey = [[NSArray alloc] initWithArray:[m_PlistDict allKeys]];
	NSArray* sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	[m_Device addItemsWithObjectValues:sortedKeys];
	[m_Device selectItemAtIndex:0];
	[self addItemsToFirmware:[sortedKeys objectAtIndex:0]];
	
	[arrayKey release];
}

- (void) addItemsToFirmware: (NSString*)device
{	
	[m_Firmware removeAllItems];
	[m_FirmwareList release];
	
	m_FirmwareList = [[NSMutableDictionary alloc] initWithDictionary:[m_PlistDict objectForKey:device]];
	
	NSArray* arrayKey = [[NSArray alloc] initWithArray:[m_FirmwareList allKeys]];
	NSArray* sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	for (int i = [sortedKeys count]; i > 0; --i) {
		[m_Firmware addItemWithObjectValue:[sortedKeys objectAtIndex:(i-1)]];
	}
	
	//[m_Firmware addItemsWithObjectValues:sortedKeys];
	[m_Firmware selectItemAtIndex:0];
	[self updateInfo:[m_Firmware stringValue]];
	
	[arrayKey release];
}

- (void) updateInfo: (NSString*)firmware
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSMutableDictionary* oneDeviceFirmware = [[NSMutableDictionary alloc] initWithDictionary:[m_FirmwareList objectForKey:firmware]];
	
	[m_FirmwareBaseband setStringValue: [m_plistParserProtocol getBaseband:oneDeviceFirmware]];
	
	[self openImageURLfor: m_FirmwareJailbreak withUrl: [NSURL fileURLWithPath: [m_plistParserProtocol getJBIndicatir:oneDeviceFirmware]]];
	
	[self openImageURLfor: m_FirmwareUnlock withUrl: [NSURL fileURLWithPath: [m_plistParserProtocol getUnlockIndicatir:oneDeviceFirmware]]];
	
	[m_FirmwareSize setStringValue:[m_plistParserProtocol getSize:oneDeviceFirmware]];

	[m_FirmwareInfo setStringValue: [m_plistParserProtocol getInfo:oneDeviceFirmware]];
	
	if (m_DownloadURL) {
		[m_DownloadURL release];
	}
	m_DownloadURL = [NSURL URLWithString:[m_plistParserProtocol getURL:oneDeviceFirmware] ];
	[m_DownloadURL retain];
	
	if ([[m_DownloadURL relativeString] length] > 0)
	{
		[m_DownloadButton setEnabled: true ];
	} else {
		[m_DownloadButton setEnabled: false ];
	}
	
	if (m_DocsURL) {
		[m_DocsURL release];
	}
	m_DocsURL = [NSURL URLWithString: [m_plistParserProtocol getDocks:oneDeviceFirmware]];
	[m_DocsURL retain];
	
	[m_FirmwareJBTools setStringValue: [m_plistParserProtocol getJBTools:oneDeviceFirmware]];
	[self setHiperLinkForTextField:m_FirmwareJBTools];
	 
	[m_FirmwareUTools setStringValue: [m_plistParserProtocol getUnlockTools:oneDeviceFirmware]];
	[self setHiperLinkForTextField:m_FirmwareUTools];
	
	[m_FirmwareSHA1 setStringValue: [m_plistParserProtocol getSHA1:oneDeviceFirmware]];
	
	[m_FirmwareBuild setStringValue: [m_plistParserProtocol getBuild:oneDeviceFirmware]];
	
	[oneDeviceFirmware release];
	[pool release];
	
}

- (void)openImageURLfor:(IKImageView*)_imageView withUrl:(NSURL*)url
{
    // use ImageIO to get the CGImage, image properties, and the image-UTType
    //
    CGImageRef          image = NULL;
    CGImageSourceRef    isr = CGImageSourceCreateWithURL( (CFURLRef)url, NULL);
	NSDictionary*		imageProperties = NULL;
    
    if (isr)
    {
		NSDictionary *options = [NSDictionary dictionaryWithObject: (id)kCFBooleanTrue  forKey: (id) kCGImageSourceShouldCache];
        image = CGImageSourceCreateImageAtIndex(isr, 0, (CFDictionaryRef)options);
        
        if (image)
        {
            imageProperties = (NSDictionary*)CGImageSourceCopyPropertiesAtIndex(isr, 0, (CFDictionaryRef)imageProperties);
        }
		CFRelease(isr);
    }
    
    if (image)
    {
        [_imageView setImage: image
             imageProperties: imageProperties];
		
		CGImageRelease(image);
		[imageProperties release];
    }
}

- (IBAction)appleInfo:(id)sender
{
	if (![self internetEnabled]) {
		return;
	}
	
	[m_Animation setHidden:false];
	[m_Animation startAnimation:self];
	
	NSString *executableName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleExecutable"];
	NSError *error;
	NSString *result = [m_plistParserProtocol findOrCreateDirectory:NSApplicationSupportDirectory
										  inDomain:NSUserDomainMask
							   appendPathComponent:executableName
											 error:&error];
	if (!result)
	{
		DBNSLog(@"Unable to find or create application support directory:\n%@", error);
	}
	
	NSData *theData = [NSData dataWithContentsOfURL:m_DocsURL];
	[theData writeToFile:[result stringByAppendingPathComponent:@"docs.zip"] atomically:YES];
	
	ZipArchive *za = [[ZipArchive alloc] init];
	if ([za UnzipOpenFile: [result stringByAppendingPathComponent:@"docs.zip"]]) {
		BOOL ret = [za UnzipFileTo: [result stringByAppendingPathComponent:@"docs"] overWrite: YES];
		
		if (NO == ret){} [za UnzipCloseFile];
	}
	[za release];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:[result stringByAppendingPathComponent:@"docs.zip"]]) {
		[[NSFileManager defaultManager] removeItemAtPath:[result stringByAppendingPathComponent:@"docs.zip"] error:nil];
	}
	
	NSString* readmeFile = [[[NSString alloc] initWithString:[result stringByAppendingPathComponent:@"docs"]] autorelease];
	NSString* sufix = [[NSString alloc] initWithString:[[[NSLocale currentLocale] localeIdentifier] substringToIndex:2]];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:[readmeFile stringByAppendingPathComponent:sufix]]) {
		readmeFile = [readmeFile stringByAppendingPathComponent:sufix];
	} else {
		readmeFile = [readmeFile stringByAppendingPathComponent:@"en"];
	}
		
	readmeFile = [readmeFile stringByAppendingPathComponent:@"ReadMe.rtf"];
	
	[m_Animation setHidden:true];
	[m_Animation stopAnimation:self];
	
	NSAlert *alert = [[NSAlert alloc] init];
	[alert addButtonWithTitle:NSLocalizedString(@"OK", @"OK")];
	[alert setMessageText:NSLocalizedString(@"Firmware Update Info", @"Firmware Update Info")];
	[alert setAlertStyle:NSInformationalAlertStyle];
	
	NSTextView	*appleFirmwareInfo;
	NSScrollView *scroll;
	
	scroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(0, 0, 400, 190)];
	appleFirmwareInfo = [[NSTextView alloc] initWithFrame:NSMakeRect(0, 0, 390, 100)];
	
	[scroll setHasVerticalScroller:YES];
	[scroll setHasHorizontalScroller:NO];
	[scroll setAutohidesScrollers:YES];
	[scroll setDocumentView:(NSView *)appleFirmwareInfo];
	
	[[appleFirmwareInfo textContainer] setContainerSize:NSMakeSize(500000.0,500000.0)];
	[[appleFirmwareInfo textContainer] setWidthTracksTextView:YES];
	[[appleFirmwareInfo textContainer] setHeightTracksTextView:NO];
	[appleFirmwareInfo setHorizontallyResizable:NO];
	[appleFirmwareInfo setVerticallyResizable:YES];
	[appleFirmwareInfo setMaxSize:NSMakeSize(500000.0,500000.0)]; 
	
    // append some coloured text
    [appleFirmwareInfo readRTFDFromFile:readmeFile];
	
	[alert setAccessoryView:scroll];
	[appleFirmwareInfo autorelease];
	[scroll autorelease];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:[result stringByAppendingPathComponent:@"docs"]]) {
		[[NSFileManager defaultManager] removeItemAtPath:[result stringByAppendingPathComponent:@"docs"] error:nil];
	}
	
	//[readmeFile release];

	[sufix release];
	
	[self startAlert:alert selector:@selector(closeFirmwareInfo:returnCode:contextInfo:)];
	[alert release];

}

#pragma mark ---- Alert / Panel----

- (void) startAlert:(NSAlert*) alert selector:(SEL)alertSelector 
{
	alertReturnStatus = -1;
	
	[alert setShowsHelp:NO];
	[alert setShowsSuppressionButton:NO];
	[alert beginSheetModalForWindow:window
					  modalDelegate:self
					 didEndSelector:alertSelector
						contextInfo:nil];
	
	NSModalSession session = [NSApp beginModalSessionForWindow:[alert window]];
	for (;;) {
		// alertReturnStatus will be set in alertDidEndSheet:returnCode:contextInfo:
		if(alertReturnStatus != -1)
			break;
		
		// Execute code on DefaultRunLoop
		[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode 
								 beforeDate:[NSDate distantFuture]];
		
		// Break the run loop if sheet was closed
		if ([NSApp runModalSession:session] != NSRunContinuesResponse 
			|| ![[alert window] isVisible]) 
			break;
		
		// Execute code on DefaultRunLoop
		[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode 
								 beforeDate:[NSDate distantFuture]];
		
	}
	[NSApp endModalSession:session];
	[NSApp endSheet:[alert window]];
}

- (void)closeAlert:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo
{	
	DBNSLog(@"clicked %d button\n", returnCode);
	if (returnCode == NSAlertSecondButtonReturn) {
		[[self bigFetchRequest] cancel];
		[self setBigFetchRequest:nil];
		[self setView:@"main"];
		NSDockTile*	dockTile = [NSApp dockTile];
		[dockTile setBadgeLabel:@""];
		
		NSString* tempFileName = [[NSString alloc] initWithString:[m_DownloadPath stringByAppendingString:@".download"]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:tempFileName]) {
			[[NSFileManager defaultManager] removeItemAtPath:tempFileName error:nil];
		}
		[tempFileName release];
	}
    // make the returnCode publicly available after closing the sheet
    alertReturnStatus = returnCode;
}

- (void)closeFirmwareInfo:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode == NSAlertSecondButtonReturn) {
		//[appleFirmwareInfo release];
	}
	alertReturnStatus = returnCode;
}

#pragma mark ---- Growl ----

- (NSDictionary *) registrationDictionaryForGrowl
{
    NSArray * notifications = [NSArray arrayWithObjects: GROWL_DOWNLOAD_COMPLETE, 
														 GROWL_DOWNLOAD_FAIL, 
														 GROWL_CHECKSUM_FAIL, 
														 GROWL_DOWNLOAD_CANCELED, 
														 GROWL_DOWNLOAD_PAUSED, 
														 GROWL_DOWNLOAD_RESUME, 
							   nil];
	
    return [NSDictionary dictionaryWithObjectsAndKeys: notifications, GROWL_NOTIFICATIONS_ALL, notifications, GROWL_NOTIFICATIONS_DEFAULT, nil];
}

- (void) growlNotificationWasClicked: (id) clickContext
{
    if (!clickContext || ![clickContext isKindOfClass: [NSDictionary class]])
        return;
    
    NSString * type = [clickContext objectForKey: @"Type"], * location;
    if (([type isEqualToString: GROWL_DOWNLOAD_COMPLETE])
		&& (location = [clickContext objectForKey: @"Location"]))
    {
		[[NSWorkspace sharedWorkspace] selectFile: location inFileViewerRootedAtPath: nil];
    }
}

#pragma mark ---- System Functions ----

- (IBAction) goToURL:(id)sender
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSURL *url = [self getHiperLinkForTool:[sender title]];
	
	[[NSWorkspace sharedWorkspace] openURL:url];
	
	[pool release];
}

- (void) setHiperLinkForTextField:(NSTextField*) textField
{
	NSMutableAttributedString *mutText = [[textField attributedStringValue] mutableCopy];
	NSString *text = [textField stringValue];
	
	NSArray *arr = [text componentsSeparatedByString:@", "];
	
	for (int i = 0; i < [arr count]; ++i) {
		NSArray *arr2 = [[arr objectAtIndex:i] componentsSeparatedByString:@" "];
		NSURL *url = [self getHiperLinkForTool:[arr2 objectAtIndex:0]];
		
		if (url == nil) {
			continue;
		}

		NSDictionary *dict = [NSDictionary dictionaryWithObject: url forKey: NSLinkAttributeName];
		NSRange range = [text rangeOfString:[arr2 objectAtIndex:0]];
		[mutText addAttributes: dict range: range];
	}
	
	[textField setAttributedStringValue: mutText];
	[textField setAllowsEditingTextAttributes: YES];
	[mutText release];
}

- (NSURL*) getHiperLinkForTool:(NSString*)tool
{
	tool = [tool lowercaseString];
	
	NSEnumerator *enumerator = [m_LinksDict keyEnumerator];
	
	for(NSString *aKey in enumerator){
		NSMutableDictionary *jbMenu = [m_LinksDict objectForKey:aKey];
		for (NSString *name in jbMenu) {
			if ([tool isEqualToString:[name lowercaseString]])
			{
				return [NSURL URLWithString:[jbMenu objectForKey:name]];
			}
		}
    }
	
	return nil;
}

- (void) setControlsEnabled:(BOOL) yesno
{
	[m_Device setEnabled: yesno ];
	[m_Firmware setEnabled: yesno ];
	[m_DownloadButton setEnabled: yesno ];
	[m_InfoButton setEnabled: yesno ];
}

- (void) playSystemSound:(NSString*) name
{
	if (!m_bUseSound) {
		return;
	}
	
	NSString* soundFile = [[NSString alloc] initWithFormat:@"/System/Library/Sounds/%@.aiff", name];
	
	NSFileManager *fm = [NSFileManager defaultManager];
	
	if ([ fm fileExistsAtPath:soundFile] == YES) {		
		NSURL* filePath = [NSURL fileURLWithPath: soundFile isDirectory: NO];
		SystemSoundID soundID;
		AudioServicesCreateSystemSoundID((CFURLRef)filePath, &soundID);
		AudioServicesPlaySystemSound(soundID);
	}
	[soundFile release];
}

- (BOOL) internetEnabled
{
	if (!m_bInternet) {
		NSAlert *alert = [[NSAlert alloc] init];
		[alert setAlertStyle:NSCriticalAlertStyle];
		[alert addButtonWithTitle:NSLocalizedString(@"OK", @"OK")];
		[alert setMessageText:NSLocalizedString(@"No Internet Connection", @"No Internet Connection")];
		[alert setInformativeText:NSLocalizedString(@"Please check your Internet connection", @"Please check your Internet connection")];
		
		[self startAlert:alert selector:@selector(closeAlert:returnCode:contextInfo:)];
		[alert release];
	}
	return m_bInternet;
}

-(void)reachabilityChanged:(NSNotification*)note
{
    Reachability * reach = [note object];
    
    if([reach isReachable])
    {
		NSMutableDictionary* dict = [m_plistParserProtocol loadListWithInterval:m_dbUpdateInterval];
        m_PlistDict = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"firmware"]];
		m_LinksDict = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"links"]];
		if (m_PlistDict) {
			[self setControlsEnabled: YES];
			
			[self addItemsToDevice];
		}
		if (m_LinksDict) {
			[self createMenus];
		}
    }
    else
    {
        [self internetEnabled];
    }
	
	[[NSNotificationCenter defaultCenter] removeObserver:self name:@"kReachabilityChangedNotification" object:nil];
}

- (IBAction)openPreference:(id) sender
{
	if (!m_Preference)
	{
		m_Preference = [[PreferenceController alloc] init];
		[[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(windowPreferenceWillClose:)
													 name:NSWindowWillCloseNotification
												   object:nil];
		[m_Preference retain];
	}
	
	[m_Preference showWindow:self];
}

- (void)windowPreferenceWillClose:(NSNotification *)notification;
{
	
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:NSWindowWillCloseNotification
												  object:nil];
	
	[m_Preference release];
	[m_Preference release];
	m_Preference = nil;
	
	NSUserDefaults* appPrefs = [NSUserDefaults standardUserDefaults];
	
	m_dbUpdateInterval = [appPrefs integerForKey:defaultsDBUpdateKey];
	m_bUseSound = [appPrefs boolForKey:defaultsUseSoundKey];
	m_bNeedCheckCRC = [appPrefs boolForKey:defaultsCheckSHA1Key];
	m_bShowNotification = [appPrefs boolForKey:defaultsUseNotificationKey];
}

- (IBAction)simpleMode:(id) sender
{
	if (m_bSimpleMode) {
		[m_simpleModeMenu setState:NSOnState];
		
		[m_DetailsBox setHidden:YES];
		[m_InfoButton setHidden:YES];
		NSRect rect = window.frame;
		rect.size.height = 108.0;
		[window setFrame:rect display:YES animate:YES];
	}
	else {
		[m_simpleModeMenu setState:NSOffState];

		[m_DetailsBox setHidden:NO];
		[m_InfoButton setHidden:NO];
		NSRect rect = window.frame;
		rect.size.height = 386.0;
		[window setFrame:rect display:YES animate:YES];
	}
	
	NSUserDefaults* appPrefs = [NSUserDefaults standardUserDefaults];
	
	[appPrefs setObject:[NSNumber numberWithBool:m_bSimpleMode]
                      forKey:defaultsSimpleModeKey];
	[appPrefs synchronize];
	
	m_bSimpleMode = !m_bSimpleMode;
}

- (IBAction)reloadDB:(id) sender
{
	if ([self internetEnabled]) {
		
		if (m_PlistDict)
			[m_PlistDict release];
		
		if (m_LinksDict) {
			[m_LinksDict release];
		}
		
		NSMutableDictionary* dict = [m_plistParserProtocol loadListWithInterval:UPDATE_AT_APP_START];
        m_PlistDict = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"firmware"]];
		m_LinksDict = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"links"]];
		if (m_PlistDict) {
			[self setControlsEnabled: YES];
			
			[self addItemsToDevice];
		}
		if (m_LinksDict) {
			[self createMenus];
		}
	}
	else {
		[self setControlsEnabled: NO];
	}
}

// Function
CFStringRef FileSHA1HashCreateWithPath(CFStringRef filePath, size_t chunkSizeForReadingData) 
{
    // Declare needed variables
    CFStringRef result = NULL;
    CFReadStreamRef readStream = NULL;
    
    // Get the file URL
    CFURLRef fileURL = 
	CFURLCreateWithFileSystemPath(kCFAllocatorDefault, 
								  (CFStringRef)filePath, 
								  kCFURLPOSIXPathStyle, 
								  (Boolean)false);
	bool didSucceed = false;
	unsigned char digest[CC_SHA1_DIGEST_LENGTH];
	
    if (fileURL)
	{
		// Create and open the read stream
		readStream = CFReadStreamCreateWithFile(kCFAllocatorDefault, 
												(CFURLRef)fileURL);
		if (readStream)
			didSucceed = (bool)CFReadStreamOpen(readStream);
		if (didSucceed)
		{
			// Initialize the hash object
			CC_SHA1_CTX hashObject;
			CC_SHA1_Init(&hashObject);
			
			// Make sure chunkSizeForReadingData is valid
			if (!chunkSizeForReadingData) {
				chunkSizeForReadingData = FileHashDefaultChunkSizeForReadingData;
			}
			
			// Feed the data to the hash object
			bool hasMoreData = true;
			while (hasMoreData) {
				uint8_t buffer[chunkSizeForReadingData];
				CFIndex readBytesCount = CFReadStreamRead(readStream, 
														  (UInt8 *)buffer, 
														  (CFIndex)sizeof(buffer));
				if (readBytesCount == -1) break;
				if (readBytesCount == 0) {
					hasMoreData = false;
					continue;
				}
				CC_SHA1_Update(&hashObject, 
							  (const void *)buffer, 
							  (CC_LONG)readBytesCount);
			}
			
			// Check if the read operation succeeded
			didSucceed = !hasMoreData;
			
			// Compute the hash digest
			
			CC_SHA1_Final(digest, &hashObject);
		}
	}
    
    // Abort if the read operation failed
    if (didSucceed)
	{
		// Compute the string result
		char hash[2 * sizeof(digest) + 1];
		for (size_t i = 0; i < sizeof(digest); ++i) {
			snprintf(hash + (2 * i), 3, "%02x", (int)(digest[i]));
		}
		result = CFStringCreateWithCString(kCFAllocatorDefault, 
										   (const char *)hash, 
										   kCFStringEncodingUTF8);
	}
    
    if (readStream) {
        CFReadStreamClose(readStream);
        CFRelease(readStream);
    }
    if (fileURL) {
        CFRelease(fileURL);
    }
    return result;
}

#pragma mark ---- Preference ----
+ (void)initialize
{
    // Create a dictionary
    NSMutableDictionary *defaultValues = [NSMutableDictionary dictionary];
	
    // Put defaults in the dictionary
	/*[defaultValues setObject:[NSString stringWithString:@"English"]
                      forKey:defaultsLanguageKey];*/
	[defaultValues setObject:[NSNumber numberWithInt:UPDATE_EVERY_DAY]
                      forKey:defaultsDBUpdateKey];
    [defaultValues setObject:[NSNumber numberWithBool:YES]
                      forKey:defaultsUseSoundKey];
	[defaultValues setObject:[NSNumber numberWithBool:NO]
                      forKey:defaultsSimpleModeKey];
	[defaultValues setObject:[NSNumber numberWithBool:YES]
                      forKey:defaultsCheckSHA1Key];
	[defaultValues setObject:[NSNumber numberWithBool:YES]
                      forKey:defaultsUseNotificationKey];
	
	
    // Register the dictionary of defaults
    [[NSUserDefaults standardUserDefaults] registerDefaults: defaultValues];

    DBNSLog(@"registered defaults: %@", defaultValues);
}
#pragma mark ---- window delegates ----

// ask to save changes if dirty
- (BOOL)windowShouldClose:(id)sender
{
#pragma unused(sender)
	
    return YES;
}

#pragma mark ---- application delegates ----

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender
{
#pragma unused(sender)
	
	/*if ([window isVisible]) {
	 [window performClose:nil];
	 }*/
    
    return NSTerminateNow;
}

// split when window is closed
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender
{
#pragma unused(sender)
	
    return YES;
}

- (void) awakeFromNib
{
	[self setView:@"main"];
}

- (void)createMenus
{
	[m_ToolsMenu removeAllItems];
	[m_SupportMenu removeAllItems];
	
	NSMutableDictionary *jbMenu = [m_LinksDict objectForKey:@"Jailbreake"];
	
	NSArray* arrayKey = [NSArray arrayWithArray:[jbMenu allKeys]];
	NSArray* sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	int i = 0;
	
	for (NSString *menuName in sortedKeys) {
		
		NSMenuItem *menuInem = [[NSMenuItem alloc] initWithTitle:menuName action:@selector(goToURL:) keyEquivalent:@""];
		NSImage *img = [NSImage imageNamed:menuName];
		if (img) {
			[menuInem setImage:img];
		}
		[m_ToolsMenu insertItem:menuInem atIndex:i++];
		[menuInem autorelease];
	}
	[m_ToolsMenu insertItem:[NSMenuItem separatorItem] atIndex:i++];
	
	jbMenu = [m_LinksDict objectForKey:@"Unlock"];
	
	arrayKey = [NSArray arrayWithArray:[jbMenu allKeys]];
	sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	for (NSString *menuName in sortedKeys) {
		NSMenuItem *menuInem = [[NSMenuItem alloc] initWithTitle:menuName action:@selector(goToURL:) keyEquivalent:@""];
		NSImage *img = [NSImage imageNamed:menuName];
		if (img) {
			[menuInem setImage:img];
		}
		[m_ToolsMenu insertItem:menuInem atIndex:i++];
		[menuInem autorelease];
	}
	[m_ToolsMenu insertItem:[NSMenuItem separatorItem] atIndex:i++];
	
	jbMenu = [m_LinksDict objectForKey:@"Tools"];
	
	arrayKey = [NSArray arrayWithArray:[jbMenu allKeys]];
	sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	for (NSString *menuName in sortedKeys) {
		NSMenuItem *menuInem = [[NSMenuItem alloc] initWithTitle:menuName action:@selector(goToURL:) keyEquivalent:@""];
		NSImage *img = [NSImage imageNamed:menuName];
		if (img) {
			[menuInem setImage:img];
		}
		[m_ToolsMenu insertItem:menuInem atIndex:i++];
		[menuInem autorelease];
	}
	
	i = 0;
	jbMenu = [m_LinksDict objectForKey:@"Support"];
	
	arrayKey = [NSArray arrayWithArray:[jbMenu allKeys]];
	sortedKeys = [arrayKey sortedArrayUsingSelector:@selector(localizedCompare:)];
	
	for (NSString *menuName in sortedKeys) {
		NSMenuItem *menuInem = [[NSMenuItem alloc] initWithTitle:menuName action:@selector(goToURL:) keyEquivalent:@""];
		NSImage *img = [NSImage imageNamed:menuName];
		if (img) {
			[menuInem setImage:img];
		}
		[m_SupportMenu insertItem:menuInem atIndex:i++];
		[menuInem autorelease];
	}
}

- (void) setView: (NSString *) viewName
{	
	NSView *view = nil;
	
	if ([viewName isEqualToString:@"main"]) {
		view = miainView;
	}
	else if ([viewName isEqualToString:@"process"]) {
		view = progressView;
	}
	
	NSWindow * _window = [self window];
	if ([_window contentView] == view)
		return;
	
	NSRect windowRect = [_window frame];
	float difference = ([view frame].size.height - [[_window contentView] frame].size.height) * [_window userSpaceScaleFactor];
	windowRect.origin.y -= difference;
	windowRect.size.height += difference;
	
	[view setHidden: YES];
	[_window setContentView: view];
	[_window setFrame: windowRect display: YES animate: YES];
	[view setHidden: NO];
}

@end
